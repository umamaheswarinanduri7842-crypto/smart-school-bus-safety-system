# 🚌 AI Smart School Bus Safety System (Educational Prototype)

A beginner-friendly **Streamlit** dashboard that demonstrates school bus safety functions
(attendance, parent notifications, accident detection, SOS alerts, GPS tracking, AI camera
scans, parent portal and reports) using **simulated data**. No hardware is required.

> ⚠️ **Prototype for educational use.** Hardware sensors and real notification services are simulated.

## Features
| Page | What it demonstrates |
|---|---|
| Dashboard | Totals, attendance chart, bus positions, notification panel, active emergencies |
| Student Attendance | Simulated RFID/NFC/QR scan, Board/Exit buttons, onboard list, student add/edit/delete, duplicate and wrong-bus/wrong-stop protection |
| Live Bus Tracking | Simulated GPS, route progress, stop geofences, off-route warning, Plotly map |
| Accident and Emergency Alerts | Simulated accelerometer/gyroscope rule with configurable thresholds; Driver SOS, Attendant SOS, Student Emergency, Accident Alert, Bus Breakdown; simulated siren; resolve buttons |
| AI Camera Surveillance | Image/video upload, mock AI detector, basic OpenCV analysis, optional YOLO; **no facial recognition** |
| Parent Portal | Student-ID lookup showing only that student's data (prototype access, no real login) |
| Reports | Date/bus/student filters, metrics, Plotly charts, CSV downloads |
| System Settings | Notification channel (SMS / Email / Mobile App - simulated), thresholds, contacts, reset demo data |

## Installation
Requires **Python 3.10+**.

```bash
cd school_bus_safety
python -m venv .venv
# Windows: .venv\Scripts\activate      macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

## Run
```bash
streamlit run app.py
```
Open the URL shown in the terminal (usually http://localhost:8501). The database and sample data are created automatically on first run.

## Prototype access
There is **no login**. The Parent Portal accepts a Student ID such as `S001`–`S010`.
Sample scan values: `RFID-1001` … `RFID-1009` (S010 has no RFID value).

## Try it (2-minute demo)
1. **Student Attendance** → scan `RFID-1001` on `BUS-101` at *Maple Street* → **Board Student**. Scan again to see duplicate blocking.
2. Scan `S006` (a BUS-102 student) on `BUS-101` → unauthorized boarding alert.
3. Choose stop *Pine Road* and press **Exit Student** for `S001` → unauthorized-stop alert; choose *Main Gate* → exit succeeds.
4. **Live Bus Tracking** → **Refresh GPS** a few times; tick *Simulate route deviation* for an off-route warning.
5. **Accident and Emergency Alerts** → *Load crash-like values* → **Generate Sensor Reading**.
6. Press **Driver SOS**, then **Resolve Alert**.
7. **AI Camera Surveillance** → **Run AI Safety Scan** (works without any upload).
8. **Parent Portal** → `S001`. **Reports** → download a CSV.

## Database (SQLite: `database/school_bus.db`)
`students`, `buses`, `bus_stops`, `attendance_events`, `notifications`, `accidents`,
`emergency_alerts`, `camera_events`, `gps_logs`, `settings`. All queries are parameterized.
Reset everything from *System Settings → Reset demo data*. Sample students live in `data/sample_students.csv`
(fictional names, placeholder phone numbers).

Attendance rules: a student may exit at their authorized stop or at the school stop (*Main Gate*);
attempts on the wrong bus or at the wrong stop are logged with status `Unauthorized bus` / `Unauthorized stop`.

## Simulated hardware
| Real-world component | In this prototype |
|---|---|
| RFID/NFC/QR reader | Text box |
| GPS module | Points moved along the stored route (`gps_tracking.py`) |
| Accelerometer / gyroscope | Number inputs, random "normal" and "crash-like" presets |
| SMS / email / mobile push | Rows in `notifications` + console print (`send_notification`) |
| Buzzer / siren | Status message |
| Camera AI | Random mock detector, simple OpenCV heuristics, optional YOLO person counting |

## Project layout
```
app.py                     Streamlit UI (all 8 pages)
modules/database.py        schema, seeding, settings, SQL helpers
modules/attendance.py      students + boarding/exit rules
modules/notifications.py   simulated notifications
modules/gps_tracking.py    simulated GPS, geofence, route progress
modules/accident_detection.py  sensor rule + manual emergency alerts
modules/camera_ai.py       mock / OpenCV / optional YOLO scan
modules/reports.py         filtered report queries + CSV
```

## Future improvements
Real authentication and roles; encrypted database or PostgreSQL; real GPS/IoT ingestion (MQTT); real SMS/email/push
providers; audit logs; better computer-vision models; driver mobile app; multi-day trips and route optimization; automated tests.

## Privacy and safety limitations
- This is a prototype, **not** a certified transportation safety system.
- GPS, RFID, sensor readings, notifications and AI detections are simulated unless real devices are connected.
- Facial recognition must not be enabled without consent and proper security controls.
- Emergency alerts here do **not** contact police, hospitals or emergency services.
- Production deployment requires authentication, encryption, access control, audit logs, secure hosting and legal compliance.
