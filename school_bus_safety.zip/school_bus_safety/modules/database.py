"""Database layer: SQLite helpers, schema creation, sample data and settings."""
from __future__ import annotations

import sqlite3
from contextlib import closing
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Optional

import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "database" / "school_bus.db"
SAMPLE_CSV = BASE_DIR / "data" / "sample_students.csv"
SCHOOL_STOP = "Main Gate"  # final stop of every route; exits here are always allowed

TABLES = ["students", "buses", "bus_stops", "attendance_events", "notifications",
          "accidents", "emergency_alerts", "camera_events", "gps_logs", "settings"]

# Default values for the settings table (all stored as text).
DEFAULT_SETTINGS = {
    "notification_channel": "Mobile App",
    "accel_threshold": "25.0",       # m/s^2 (normal gravity alone is ~9.8)
    "gyro_threshold": "250.0",       # degrees/second
    "route_tolerance_m": "150",      # metres from route before "off route" warning
    "emergency_contacts": ("School Administrator: 555-0100\n"
                           "Transport Coordinator: 555-0142\n"
                           "Local emergency services (SIMULATED - never called automatically): 555-0199"),
}

SCHEMA = """
CREATE TABLE IF NOT EXISTS students (
    student_id TEXT PRIMARY KEY, name TEXT NOT NULL, class_name TEXT, parent_name TEXT,
    parent_phone TEXT, bus_id TEXT, stop_name TEXT, rfid_code TEXT UNIQUE);
CREATE TABLE IF NOT EXISTS buses (
    bus_id TEXT PRIMARY KEY, route_name TEXT, driver_name TEXT, capacity INTEGER);
CREATE TABLE IF NOT EXISTS bus_stops (
    id INTEGER PRIMARY KEY AUTOINCREMENT, bus_id TEXT NOT NULL, stop_order INTEGER NOT NULL,
    stop_name TEXT NOT NULL, latitude REAL, longitude REAL, radius_m REAL DEFAULT 120);
CREATE TABLE IF NOT EXISTS attendance_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT, student_id TEXT, student_name TEXT, event_type TEXT,
    event_time TEXT, bus_id TEXT, stop_name TEXT, verification_status TEXT);
CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT, student_id TEXT, bus_id TEXT, recipient TEXT,
    channel TEXT, category TEXT, message TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS accidents (
    accident_id INTEGER PRIMARY KEY AUTOINCREMENT, bus_id TEXT, event_time TEXT, latitude REAL,
    longitude REAL, sensor_readings TEXT, severity TEXT, status TEXT DEFAULT 'New');
CREATE TABLE IF NOT EXISTS emergency_alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT, bus_id TEXT, alert_type TEXT, latitude REAL,
    longitude REAL, created_at TEXT, status TEXT DEFAULT 'Active', resolved_at TEXT);
CREATE TABLE IF NOT EXISTS camera_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT, bus_id TEXT, camera_location TEXT, detection TEXT,
    confidence REAL, severity TEXT, mode TEXT, media_name TEXT, details TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS gps_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT, bus_id TEXT, latitude REAL, longitude REAL, speed REAL,
    current_stop TEXT, progress REAL, off_route INTEGER, logged_at TEXT);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
"""

# ---- Demo seed data (fictional; coordinates are arbitrary demo values) ----
BUSES = [("BUS-101", "Route A - North Loop", "Demo Driver A", 40),
         ("BUS-102", "Route B - South Loop", "Demo Driver B", 40)]
STOPS = {
    "BUS-101": [("Maple Street", 34.0700, -118.2700), ("Oak Avenue", 34.0650, -118.2620),
                ("Pine Road", 34.0580, -118.2550), (SCHOOL_STOP, 34.0500, -118.2500)],
    "BUS-102": [("Cedar Lane", 34.0400, -118.2800), ("Elm Street", 34.0440, -118.2700),
                ("Birch Road", 34.0470, -118.2590), (SCHOOL_STOP, 34.0500, -118.2500)],
}
SAMPLE_COLUMNS = ["student_id", "name", "class_name", "parent_name", "parent_phone",
                  "bus_id", "stop_name", "rfid_code"]
SAMPLE_ROWS = [
    ("S001", "Aarav", "5A", "Demo Parent 1", "555-0101", "BUS-101", "Maple Street", "RFID-1001"),
    ("S002", "Diya", "5B", "Demo Parent 2", "555-0102", "BUS-101", "Maple Street", "RFID-1002"),
    ("S003", "Kabir", "6A", "Demo Parent 3", "555-0103", "BUS-101", "Oak Avenue", "RFID-1003"),
    ("S004", "Meera", "6B", "Demo Parent 4", "555-0104", "BUS-101", "Pine Road", "RFID-1004"),
    ("S005", "Rohan", "7A", "Demo Parent 5", "555-0105", "BUS-101", "Pine Road", "RFID-1005"),
    ("S006", "Ananya", "5A", "Demo Parent 6", "555-0106", "BUS-102", "Cedar Lane", "RFID-1006"),
    ("S007", "Ishaan", "6A", "Demo Parent 7", "555-0107", "BUS-102", "Cedar Lane", "RFID-1007"),
    ("S008", "Sara", "7B", "Demo Parent 8", "555-0108", "BUS-102", "Elm Street", "RFID-1008"),
    ("S009", "Vihaan", "8A", "Demo Parent 9", "555-0109", "BUS-102", "Birch Road", "RFID-1009"),
    ("S010", "Zoya", "8B", "Demo Parent 10", "555-0110", "BUS-102", "Birch Road", ""),
]


# ---------------------------------------------------------------- helpers
def now_str() -> str:
    """Current local time as 'YYYY-MM-DD HH:MM:SS' (the format stored in SQLite)."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def fmt_time(ts: str) -> str:
    """'2026-01-05 07:35:10' -> '7:35 AM' (falls back to the raw text)."""
    try:
        return datetime.strptime(ts, "%Y-%m-%d %H:%M:%S").strftime("%I:%M %p").lstrip("0")
    except (ValueError, TypeError):
        return str(ts)


def get_conn() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def execute(sql: str, params: tuple = ()) -> int:
    """Run a write statement (parameterized) and return the last row id."""
    with closing(get_conn()) as conn, conn:
        return conn.execute(sql, params).lastrowid


def query_df(sql: str, params: tuple = ()) -> pd.DataFrame:
    with closing(get_conn()) as conn:
        return pd.read_sql_query(sql, conn, params=params)


def fetch_one(sql: str, params: tuple = ()) -> Optional[dict[str, Any]]:
    with closing(get_conn()) as conn:
        row = conn.execute(sql, params).fetchone()
        return dict(row) if row else None


def get_setting(key: str, default: str = "") -> str:
    row = fetch_one("SELECT value FROM settings WHERE key = ?", (key,))
    return row["value"] if row else DEFAULT_SETTINGS.get(key, default)


def set_setting(key: str, value: Any) -> None:
    execute("INSERT INTO settings (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value", (key, str(value)))


# ---------------------------------------------------------------- setup
def ensure_sample_csv() -> None:
    """Create data/sample_students.csv from SAMPLE_ROWS if it is missing."""
    if not SAMPLE_CSV.exists():
        SAMPLE_CSV.parent.mkdir(parents=True, exist_ok=True)
        pd.DataFrame(SAMPLE_ROWS, columns=SAMPLE_COLUMNS).to_csv(SAMPLE_CSV, index=False)


def _seed_history() -> None:
    """A little history from 'yesterday' so reports and charts are not empty."""
    y = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    ev = [("S001", "Aarav", "Boarded", "07:35", "BUS-101", "Maple Street", "Verified"),
          ("S002", "Diya", "Boarded", "07:37", "BUS-101", "Maple Street", "Verified"),
          ("S001", "Aarav", "Exited", "08:10", "BUS-101", "Main Gate", "Verified"),
          ("S002", "Diya", "Exited", "08:10", "BUS-101", "Main Gate", "Verified"),
          ("S006", "Ananya", "Boarded", "07:50", "BUS-101", "Oak Avenue", "Unauthorized bus")]
    for sid, name, typ, hm, bus, stop, status in ev:
        execute("INSERT INTO attendance_events (student_id, student_name, event_type, event_time, "
                "bus_id, stop_name, verification_status) VALUES (?,?,?,?,?,?,?)",
                (sid, name, typ, f"{y} {hm}:00", bus, stop, status))
    execute("INSERT INTO accidents (bus_id, event_time, latitude, longitude, sensor_readings, severity, status) "
            "VALUES (?,?,?,?,?,?,?)", ("BUS-101", f"{y} 08:00:00", 34.062, -118.259,
                                        '{"note": "demo history"}', "Moderate", "Resolved"))
    execute("INSERT INTO emergency_alerts (bus_id, alert_type, latitude, longitude, created_at, status, resolved_at) "
            "VALUES (?,?,?,?,?,?,?)", ("BUS-102", "Bus Breakdown", 34.044, -118.270,
                                        f"{y} 07:40:00", "Resolved", f"{y} 08:05:00"))
    execute("INSERT INTO camera_events (bus_id, camera_location, detection, confidence, severity, mode, "
            "media_name, details, created_at) VALUES (?,?,?,?,?,?,?,?,?)",
            ("BUS-101", "Front Door", "Door-area activity", 0.71, "Low", "Simulated", "demo",
             "demo history", f"{y} 07:36:00"))


def _seed() -> None:
    ensure_sample_csv()
    for b in BUSES:
        execute("INSERT OR IGNORE INTO buses VALUES (?,?,?,?)", b)
    for bus_id, stops in STOPS.items():
        for order, (name, lat, lon) in enumerate(stops, start=1):
            execute("INSERT INTO bus_stops (bus_id, stop_order, stop_name, latitude, longitude) "
                    "VALUES (?,?,?,?,?)", (bus_id, order, name, lat, lon))
    students = pd.read_csv(SAMPLE_CSV, dtype=str).fillna("")
    for r in students.to_dict("records"):
        execute("INSERT OR IGNORE INTO students VALUES (?,?,?,?,?,?,?,?)",
                (r["student_id"], r["name"], r["class_name"], r["parent_name"], r["parent_phone"],
                 r["bus_id"], r["stop_name"], r["rfid_code"] or None))
    _seed_history()


def init_db() -> None:
    """Create all tables, default settings and (on first run) the sample data."""
    with closing(get_conn()) as conn, conn:
        conn.executescript(SCHEMA)
    for k, v in DEFAULT_SETTINGS.items():
        execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (k, v))
    if query_df("SELECT COUNT(*) AS n FROM buses")["n"][0] == 0:
        _seed()


def reset_demo_data() -> None:
    """Delete every record and re-create the sample data."""
    with closing(get_conn()) as conn, conn:
        for table in TABLES:
            conn.execute(f"DELETE FROM {table}")  # table names come from the constant list above
    init_db()
