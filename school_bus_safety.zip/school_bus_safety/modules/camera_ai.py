"""Camera surveillance: mock AI detector, basic OpenCV analysis and optional YOLO.
No facial recognition is implemented."""
from __future__ import annotations

import os
import random
import tempfile
from typing import Any

import numpy as np
import pandas as pd

try:
    import cv2  # OpenCV
except ImportError:  # the app still runs; OpenCV mode is disabled
    cv2 = None

from . import database as db
from . import notifications as notif

CAMERA_LOCATIONS = ["Front Door", "Rear Door", "Interior - Aisle", "Driver Cabin"]
# detection -> severity
DETECTIONS = {"Normal activity": "Info", "Possible unauthorized entry": "High",
              "Possible student fight": "High", "Suspicious activity": "Medium", "Door-area activity": "Low"}
MODE_MOCK, MODE_CV, MODE_YOLO = "Simulated AI detector (mock)", "Basic OpenCV analysis", "YOLO (optional)"


def opencv_available() -> bool:
    return cv2 is not None


def yolo_available() -> bool:
    try:
        import ultralytics  # noqa: F401
        return True
    except Exception:
        return False


def mock_detect() -> dict[str, Any]:
    """Random detection, weighted so 'Normal activity' is the most common outcome."""
    name = random.choices(list(DETECTIONS), weights=[50, 10, 10, 15, 15])[0]
    conf = random.uniform(0.85, 0.98) if name == "Normal activity" else random.uniform(0.55, 0.92)
    return {"detection": name, "confidence": round(conf, 2), "details": "Random demo result (no real analysis)."}


def _decode_image(data: bytes) -> np.ndarray:
    img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("Could not read the image file.")
    return img


def analyze_image(data: bytes) -> dict[str, Any]:
    """Heuristic: very dark or very blurry frames are flagged as a possible obstructed camera."""
    gray = cv2.cvtColor(_decode_image(data), cv2.COLOR_BGR2GRAY)
    brightness, sharpness = float(gray.mean()), float(cv2.Laplacian(gray, cv2.CV_64F).var())
    details = f"brightness={brightness:.0f}/255, sharpness={sharpness:.0f}"
    if brightness < 40 or sharpness < 15:
        return {"detection": "Suspicious activity", "confidence": 0.60,
                "details": f"Dark/blurry frame - possible camera obstruction ({details})."}
    return {"detection": "Normal activity", "confidence": 0.70, "details": f"Frame looks normal ({details})."}


def analyze_video(data: bytes, suffix: str = ".mp4") -> dict[str, Any]:
    """Frame-differencing: the share of pixels that change between sampled frames = motion level."""
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(data)
        path = tmp.name
    try:
        cap = cv2.VideoCapture(path)
        if not cap.isOpened():
            raise ValueError("Could not open the video file.")
        prev, ratios, idx = None, [], 0
        while len(ratios) < 60:
            ok, frame = cap.read()
            if not ok:
                break
            idx += 1
            if idx % 3:  # look at every 3rd frame
                continue
            gray = cv2.GaussianBlur(cv2.cvtColor(cv2.resize(frame, (320, 180)), cv2.COLOR_BGR2GRAY), (5, 5), 0)
            if prev is not None:
                ratios.append(float((cv2.absdiff(prev, gray) > 25).mean()))
            prev = gray
        cap.release()
    finally:
        os.remove(path)
    if not ratios:
        raise ValueError("The video is too short to analyse.")
    motion = float(np.mean(ratios))
    conf = round(min(0.95, 0.5 + motion), 2)
    details = f"average motion={motion:.1%} over {len(ratios)} sampled frame pairs"
    if motion > 0.25:
        return {"detection": "Possible student fight", "confidence": conf, "details": f"Very high motion ({details})."}
    if motion > 0.08:
        return {"detection": "Door-area activity", "confidence": conf, "details": f"Moderate motion ({details})."}
    return {"detection": "Normal activity", "confidence": conf, "details": f"Low motion ({details})."}


def yolo_scan(data: bytes) -> dict[str, Any]:
    """Optional: count people with YOLOv8 (weights download on first use)."""
    from ultralytics import YOLO
    result = YOLO("yolov8n.pt")(_decode_image(data), verbose=False)[0]
    persons = [b for b in result.boxes if int(b.cls) == 0]
    conf = round(float(max((float(b.conf) for b in persons), default=0.6)), 2)
    if len(persons) >= 6:
        return {"detection": "Door-area activity", "confidence": conf, "details": f"{len(persons)} people detected (crowding)."}
    return {"detection": "Normal activity", "confidence": conf, "details": f"{len(persons)} people detected."}


def run_scan(mode: str, media: bytes | None, media_name: str, is_video: bool,
             camera_location: str, bus_id: str) -> dict[str, Any]:
    """Run the chosen detector, save the event to camera_events and return it."""
    if mode == MODE_MOCK or media is None:
        res = mock_detect()
    elif mode == MODE_CV:
        if not opencv_available():
            raise RuntimeError("OpenCV is not installed. Run: pip install opencv-python-headless")
        res = analyze_video(media, os.path.splitext(media_name)[1] or ".mp4") if is_video else analyze_image(media)
    else:
        if is_video:
            raise ValueError("YOLO mode supports images only in this prototype.")
        res = yolo_scan(media)
    res.update(severity=DETECTIONS[res["detection"]], camera_location=camera_location, bus_id=bus_id,
               mode=mode, time=db.now_str())
    db.execute("INSERT INTO camera_events (bus_id, camera_location, detection, confidence, severity, mode, "
               "media_name, details, created_at) VALUES (?,?,?,?,?,?,?,?,?)",
               (bus_id, camera_location, res["detection"], res["confidence"], res["severity"], mode,
                media_name or "(none)", res["details"], res["time"]))
    if res["severity"] == "High":
        notif.notify_admin(f"{res['detection']} on {bus_id} ({camera_location}), confidence {res['confidence']:.0%}. "
                           "Simulated detection - please verify manually.", "warning", bus_id)
    return res


def list_camera_events(limit: int = 50) -> pd.DataFrame:
    return db.query_df("SELECT * FROM camera_events ORDER BY id DESC LIMIT ?", (limit,))
