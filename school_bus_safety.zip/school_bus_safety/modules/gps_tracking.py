"""Simulated GPS: a bus moves along its stop-to-stop route; includes geofence checks."""
from __future__ import annotations

import math
import random
from typing import Any

import pandas as pd

from . import database as db


def get_route(bus_id: str) -> pd.DataFrame:
    return db.query_df("SELECT stop_order, stop_name, latitude, longitude, radius_m FROM bus_stops "
                       "WHERE bus_id = ? ORDER BY stop_order", (bus_id,))


def get_route_name(bus_id: str) -> str:
    row = db.fetch_one("SELECT route_name FROM buses WHERE bus_id = ?", (bus_id,))
    return row["route_name"] if row else "Unknown route"


def haversine_m(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance in metres."""
    r = 6_371_000
    p1, p2 = math.radians(lat1), math.radians(lat2)
    a = (math.sin((p2 - p1) / 2) ** 2
         + math.cos(p1) * math.cos(p2) * math.sin(math.radians(lon2 - lon1) / 2) ** 2)
    return 2 * r * math.asin(math.sqrt(a))


def _xy(lat: float, lon: float, lat0: float) -> tuple[float, float]:
    """Flat-earth approximation in metres (fine for a few km)."""
    return lon * 111_320 * math.cos(math.radians(lat0)), lat * 110_540


def distance_to_route_m(lat: float, lon: float, stops: list[dict]) -> float:
    """Shortest distance from a point to the polyline joining the stops."""
    p = _xy(lat, lon, lat)
    best = float("inf")
    for a, b in zip(stops, stops[1:]):
        ax, ay = _xy(a["latitude"], a["longitude"], lat)
        bx, by = _xy(b["latitude"], b["longitude"], lat)
        dx, dy = bx - ax, by - ay
        length2 = dx * dx + dy * dy
        t = 0 if length2 == 0 else max(0, min(1, ((p[0] - ax) * dx + (p[1] - ay) * dy) / length2))
        best = min(best, math.hypot(p[0] - (ax + t * dx), p[1] - (ay + t * dy)))
    return best


def _segment_lengths(stops: list[dict]) -> list[float]:
    return [haversine_m(a["latitude"], a["longitude"], b["latitude"], b["longitude"])
            for a, b in zip(stops, stops[1:])]


def position_at_progress(stops: list[dict], progress: float) -> tuple[float, float]:
    """Latitude/longitude after travelling `progress` percent of the route."""
    lengths = _segment_lengths(stops)
    target = sum(lengths) * max(0.0, min(100.0, progress)) / 100
    for (a, b), seg in zip(zip(stops, stops[1:]), lengths):
        if target <= seg or seg == 0:
            f = 0 if seg == 0 else target / seg
            return (a["latitude"] + f * (b["latitude"] - a["latitude"]),
                    a["longitude"] + f * (b["longitude"] - a["longitude"]))
        target -= seg
    return stops[-1]["latitude"], stops[-1]["longitude"]


def stop_progress_points(stops: list[dict]) -> list[float]:
    """Route progress (%) at which each stop is reached."""
    lengths = _segment_lengths(stops)
    total, acc, points = (sum(lengths) or 1), 0.0, [0.0]
    for seg in lengths:
        acc += seg
        points.append(round(acc / total * 100, 1))
    return points


def _current_stop(lat: float, lon: float, stops: list[dict]) -> str:
    """Geofence check: inside a stop's radius -> that stop's name."""
    for s in stops:
        if haversine_m(lat, lon, s["latitude"], s["longitude"]) <= (s["radius_m"] or 120):
            return s["stop_name"]
    return "In transit"


def refresh_gps(bus_id: str, step: float | None = None, deviate: bool = False) -> dict[str, Any]:
    """Advance the simulated bus, log the position and return it."""
    stops = get_route(bus_id).to_dict("records")
    if len(stops) < 2:
        raise ValueError(f"{bus_id} needs at least two stops to simulate a route.")
    prev = db.fetch_one("SELECT progress FROM gps_logs WHERE bus_id = ? ORDER BY id DESC LIMIT 1", (bus_id,))
    progress = prev["progress"] if prev else 0.0
    step = random.uniform(4, 9) if step is None else step
    progress = 0.0 if progress >= 100 and step > 0 else min(100.0, progress + step)
    lat, lon = position_at_progress(stops, progress)
    if deviate:  # demo: push the bus roughly 800 m off the route
        lat, lon = lat + 0.006, lon + 0.006
    tolerance = float(db.get_setting("route_tolerance_m", "150"))
    off_route = distance_to_route_m(lat, lon, stops) > tolerance
    speed = 0.0 if step == 0 else round(random.uniform(25, 45), 1)
    stop = _current_stop(lat, lon, stops)
    db.execute("INSERT INTO gps_logs (bus_id, latitude, longitude, speed, current_stop, progress, off_route, logged_at) "
               "VALUES (?,?,?,?,?,?,?,?)", (bus_id, lat, lon, speed, stop, progress, int(off_route), db.now_str()))
    return latest_position(bus_id)


def latest_position(bus_id: str) -> dict[str, Any]:
    row = db.fetch_one("SELECT * FROM gps_logs WHERE bus_id = ? ORDER BY id DESC LIMIT 1", (bus_id,))
    if row is None:
        return refresh_gps(bus_id, step=0)  # first call: park the bus at the first stop
    row["off_route"] = bool(row["off_route"])
    return row


def recent_logs(bus_id: str, limit: int = 20) -> pd.DataFrame:
    return db.query_df("SELECT logged_at, latitude, longitude, speed, current_stop, progress, off_route "
                       "FROM gps_logs WHERE bus_id = ? ORDER BY id DESC LIMIT ?", (bus_id, limit))
