"""Report queries (all parameterized) and CSV export helpers."""
from __future__ import annotations

from typing import Optional

import pandas as pd

from . import attendance
from . import database as db


def _filtered(table: str, time_col: str, start: str, end: str, bus: Optional[str],
              student: Optional[str] = None, extra: str = "") -> pd.DataFrame:
    """SELECT * from a fixed table name with date/bus/student filters (values are bound parameters)."""
    where, params = [f"date({time_col}) BETWEEN ? AND ?"], [start, end]
    if bus:
        where.append("bus_id = ?")
        params.append(bus)
    if student:
        where.append("student_id = ?")
        params.append(student)
    if extra:
        where.append(extra)
    return db.query_df(f"SELECT * FROM {table} WHERE {' AND '.join(where)} ORDER BY {time_col} DESC", tuple(params))


def daily_attendance(start, end, bus=None, student=None) -> pd.DataFrame:
    return _filtered("attendance_events", "event_time", start, end, bus, student,
                     "verification_status = 'Verified'")


def onboard_now(bus=None, student=None) -> pd.DataFrame:
    df = attendance.currently_onboard(bus)
    return df[df["student_id"] == student] if student else df


def unauthorized_attempts(start, end, bus=None, student=None) -> pd.DataFrame:
    return _filtered("attendance_events", "event_time", start, end, bus, student,
                     "verification_status LIKE 'Unauthorized%'")


def accident_history(start, end, bus=None) -> pd.DataFrame:
    return _filtered("accidents", "event_time", start, end, bus)


def emergency_history(start, end, bus=None) -> pd.DataFrame:
    return _filtered("emergency_alerts", "created_at", start, end, bus)


def camera_history(start, end, bus=None) -> pd.DataFrame:
    return _filtered("camera_events", "created_at", start, end, bus)


def bus_activity(start, end, bus=None) -> pd.DataFrame:
    """One row per bus summarising events in the period."""
    buses = [bus] if bus else db.query_df("SELECT bus_id FROM buses")["bus_id"].tolist()
    rows = []
    for b in buses:
        att = _filtered("attendance_events", "event_time", start, end, b)
        ok = att[att["verification_status"] == "Verified"]
        rows.append({"bus_id": b,
                     "boardings": int((ok["event_type"] == "Boarded").sum()),
                     "exits": int((ok["event_type"] == "Exited").sum()),
                     "unauthorized_attempts": int(att["verification_status"].str.startswith("Unauthorized").sum()),
                     "accidents": len(accident_history(start, end, b)),
                     "emergency_alerts": len(emergency_history(start, end, b)),
                     "camera_events": len(camera_history(start, end, b)),
                     "gps_updates": len(_filtered("gps_logs", "logged_at", start, end, b))})
    return pd.DataFrame(rows)


def to_csv_bytes(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False).encode("utf-8")
