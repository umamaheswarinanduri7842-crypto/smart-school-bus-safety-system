"""Simulated notification system. Nothing is sent to real SMS/email/app services."""
from __future__ import annotations

import pandas as pd

from . import database as db

CHANNELS = ["SMS", "Email", "Mobile App"]
CATEGORY_COLORS = {"emergency": "red", "warning": "orange", "success": "green", "info": "blue"}


def send_notification(student_id: str | None, message: str, category: str = "info",
                      bus_id: str | None = None, recipient: str = "Parent") -> int:
    """Store a notification and 'send' it through the configured simulated channel."""
    channel = db.get_setting("notification_channel", "Mobile App")
    try:
        nid = db.execute(
            "INSERT INTO notifications (student_id, bus_id, recipient, channel, category, message, created_at) "
            "VALUES (?,?,?,?,?,?,?)", (student_id, bus_id, recipient, channel, category, message, db.now_str()))
    except Exception as exc:  # never let a notification failure break the app
        print(f"[notification error] {exc}")
        return -1
    print(f"[SIMULATED {channel}] to {recipient}: {message}")  # placeholder for a real SMS/email API
    return nid


def notify_admin(message: str, category: str = "info", bus_id: str | None = None) -> int:
    return send_notification(None, message, category, bus_id, recipient="School Administrator")


def notify_bus_parents(bus_id: str, message: str, category: str = "info") -> int:
    """Send the same simulated message to the parent of every student assigned to a bus."""
    students = db.query_df("SELECT student_id FROM students WHERE bus_id = ?", (bus_id,))
    for sid in students["student_id"]:
        send_notification(sid, message, category, bus_id)
    return len(students)


def get_notifications(student_id: str | None = None, limit: int = 50) -> pd.DataFrame:
    if student_id:
        return db.query_df("SELECT * FROM notifications WHERE student_id = ? ORDER BY id DESC LIMIT ?",
                           (student_id, limit))
    return db.query_df("SELECT * FROM notifications ORDER BY id DESC LIMIT ?", (limit,))
