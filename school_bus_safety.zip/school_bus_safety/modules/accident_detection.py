"""Simulated accident detection (accelerometer/gyroscope rule) and manual emergency alerts."""
from __future__ import annotations

import json
import math
from typing import Any

import pandas as pd

from . import database as db
from . import gps_tracking as gps
from . import notifications as notif

ALERT_TYPES = ["Driver SOS", "Attendant SOS", "Student Emergency", "Accident Alert", "Bus Breakdown"]
OPEN_ACCIDENT_STATUSES = ("New", "Investigating")


def magnitude(x: float, y: float, z: float) -> float:
    return math.sqrt(x * x + y * y + z * z)


def get_thresholds() -> tuple[float, float]:
    return float(db.get_setting("accel_threshold", "25")), float(db.get_setting("gyro_threshold", "250"))


def get_emergency_contacts() -> list[str]:
    return [ln.strip() for ln in db.get_setting("emergency_contacts").splitlines() if ln.strip()]


def evaluate_reading(reading: dict[str, Any]) -> dict[str, Any]:
    """Rule: accident if acceleration OR gyroscope magnitude exceeds its threshold."""
    a_thr, g_thr = get_thresholds()
    a_mag = magnitude(reading["ax"], reading["ay"], reading["az"])
    g_mag = magnitude(reading["gx"], reading["gy"], reading["gz"])
    ratio = max(a_mag / a_thr if a_thr else 0, g_mag / g_thr if g_thr else 0)
    severity = "Critical" if ratio >= 2 else "High" if ratio >= 1.5 else "Moderate" if ratio >= 1 else "None"
    return {"accel_mag": round(a_mag, 2), "gyro_mag": round(g_mag, 2), "detected": ratio >= 1,
            "severity": severity, "accel_threshold": a_thr, "gyro_threshold": g_thr}


def record_accident(bus_id: str, reading: dict[str, Any], severity: str) -> int:
    return db.execute("INSERT INTO accidents (bus_id, event_time, latitude, longitude, sensor_readings, severity, status) "
                      "VALUES (?,?,?,?,?,?,'New')",
                      (bus_id, db.now_str(), reading["latitude"], reading["longitude"],
                       json.dumps(reading, default=str), severity))


def process_reading(bus_id: str, reading: dict[str, Any]) -> dict[str, Any]:
    """Evaluate a reading; when it is an accident, save it and send simulated notifications."""
    result = evaluate_reading(reading)
    result["accident_id"] = None
    if result["detected"]:
        result["accident_id"] = record_accident(bus_id, reading, result["severity"])
        where = f"{reading['latitude']:.5f}, {reading['longitude']:.5f}"
        notif.notify_admin(f"EMERGENCY: possible accident on {bus_id} (severity {result['severity']}) at {where}. "
                           "Simulated alert - no emergency service was contacted.", "emergency", bus_id)
        notif.notify_bus_parents(bus_id, f"Emergency notice: a possible incident was detected on Bus {bus_id}. "
                                         "The school is checking. (simulated)", "emergency")
    return result


def list_accidents(open_only: bool = False) -> pd.DataFrame:
    sql = "SELECT * FROM accidents"
    if open_only:
        sql += " WHERE status IN ('New','Investigating')"
    return db.query_df(sql + " ORDER BY accident_id DESC")


def update_accident_status(accident_id: int, status: str) -> None:
    db.execute("UPDATE accidents SET status = ? WHERE accident_id = ?", (status, accident_id))
    if status == "Resolved":
        notif.notify_admin(f"Accident #{accident_id} marked Resolved.", "success")


# ---------------------------------------------------------------- manual emergency alerts
def create_emergency_alert(bus_id: str, alert_type: str) -> dict[str, Any]:
    pos = gps.latest_position(bus_id)
    alert_id = db.execute("INSERT INTO emergency_alerts (bus_id, alert_type, latitude, longitude, created_at, status) "
                          "VALUES (?,?,?,?,?,'Active')",
                          (bus_id, alert_type, pos["latitude"], pos["longitude"], db.now_str()))
    when = db.fmt_time(db.now_str())
    notif.notify_admin(f"{alert_type} on {bus_id} at {when}. GPS {pos['latitude']:.5f}, {pos['longitude']:.5f}. (simulated)",
                       "emergency", bus_id)
    notif.notify_bus_parents(bus_id, f"Emergency notice ({alert_type}) on Bus {bus_id} at {when}. "
                                     "The school has been alerted. (simulated)", "emergency")
    return {"id": alert_id, "bus_id": bus_id, "alert_type": alert_type, "time": when, **pos}


def resolve_alert(alert_id: int) -> None:
    db.execute("UPDATE emergency_alerts SET status = 'Resolved', resolved_at = ? WHERE id = ?",
               (db.now_str(), alert_id))
    notif.notify_admin(f"Emergency alert #{alert_id} resolved.", "success")


def list_alerts(status: str | None = None, bus_id: str | None = None) -> pd.DataFrame:
    sql, params, where = "SELECT * FROM emergency_alerts", [], []
    if status:
        where.append("status = ?")
        params.append(status)
    if bus_id:
        where.append("bus_id = ?")
        params.append(bus_id)
    if where:
        sql += " WHERE " + " AND ".join(where)
    return db.query_df(sql + " ORDER BY id DESC", tuple(params))


def siren_active() -> bool:
    """Simulated buzzer/siren: on while any alert or accident is still open."""
    return (not list_alerts(status="Active").empty) or (not list_accidents(open_only=True).empty)
