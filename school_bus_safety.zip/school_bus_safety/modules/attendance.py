"""Student records, simulated RFID/QR scanning and boarding/exit rules."""
from __future__ import annotations

import sqlite3
from typing import Any, Optional

import pandas as pd

from . import database as db
from . import gps_tracking as gps
from . import notifications as notif

TODAY = "date('now','localtime')"
FIELDS = ["student_id", "name", "class_name", "parent_name", "parent_phone", "bus_id", "stop_name", "rfid_code"]


def _result(level: str, message: str) -> dict[str, str]:
    """Uniform result used by the UI: level is success | warning | error | info."""
    return {"level": level, "message": message}


# ---------------------------------------------------------------- student CRUD
def list_students(bus_id: Optional[str] = None) -> pd.DataFrame:
    if bus_id:
        return db.query_df("SELECT * FROM students WHERE bus_id = ? ORDER BY student_id", (bus_id,))
    return db.query_df("SELECT * FROM students ORDER BY student_id")


def get_student(student_id: str) -> Optional[dict[str, Any]]:
    """Look up by Student ID only (case-insensitive)."""
    return db.fetch_one("SELECT * FROM students WHERE UPPER(student_id) = UPPER(?)", (student_id.strip(),))


def find_student(code: str) -> Optional[dict[str, Any]]:
    """Look up by scanned RFID/NFC/QR value or by Student ID."""
    code = code.strip()
    if not code:
        return None
    return db.fetch_one("SELECT * FROM students WHERE UPPER(student_id) = UPPER(?) "
                        "OR (rfid_code IS NOT NULL AND UPPER(rfid_code) = UPPER(?))", (code, code))


def _validate(data: dict[str, str]) -> Optional[str]:
    if not data["student_id"].strip() or not data["name"].strip():
        return "Student ID and name are required."
    if not data["bus_id"]:
        return "Please choose a bus."
    if data["stop_name"] not in gps.get_route(data["bus_id"])["stop_name"].tolist():
        return f"'{data['stop_name']}' is not a stop on {data['bus_id']}."
    return None


def _clean(data: dict[str, str]) -> dict[str, Any]:
    out = {k: (data.get(k) or "").strip() for k in FIELDS}
    out["rfid_code"] = out["rfid_code"] or None  # optional and unique
    return out


def add_student(data: dict[str, str]) -> dict[str, str]:
    data = _clean(data)
    error = _validate(data)
    if error:
        return _result("error", error)
    try:
        db.execute("INSERT INTO students VALUES (?,?,?,?,?,?,?,?)", tuple(data[k] for k in FIELDS))
    except sqlite3.IntegrityError:
        return _result("error", "That Student ID or RFID/QR value already exists.")
    return _result("success", f"Student {data['name']} added.")


def update_student(data: dict[str, str]) -> dict[str, str]:
    data = _clean(data)
    error = _validate(data)
    if error:
        return _result("error", error)
    try:
        db.execute("UPDATE students SET name=?, class_name=?, parent_name=?, parent_phone=?, bus_id=?, "
                   "stop_name=?, rfid_code=? WHERE student_id=?",
                   (data["name"], data["class_name"], data["parent_name"], data["parent_phone"],
                    data["bus_id"], data["stop_name"], data["rfid_code"], data["student_id"]))
    except sqlite3.IntegrityError:
        return _result("error", "That RFID/QR value is already used by another student.")
    return _result("success", f"Student {data['name']} updated.")


def delete_student(student_id: str) -> dict[str, str]:
    db.execute("DELETE FROM students WHERE student_id = ?", (student_id,))
    return _result("success", f"Student {student_id} deleted (past attendance history is kept).")


# ---------------------------------------------------------------- attendance logic
def _log(student: dict, event_type: str, bus_id: str, stop: str, status: str) -> None:
    db.execute("INSERT INTO attendance_events (student_id, student_name, event_type, event_time, bus_id, "
               "stop_name, verification_status) VALUES (?,?,?,?,?,?,?)",
               (student["student_id"], student["name"], event_type, db.now_str(), bus_id, stop, status))


def is_onboard(student_id: str) -> bool:
    """True if the student's latest VERIFIED event today is 'Boarded'."""
    row = db.fetch_one("SELECT event_type FROM attendance_events WHERE student_id = ? "
                       f"AND verification_status = 'Verified' AND date(event_time) = {TODAY} "
                       "ORDER BY id DESC LIMIT 1", (student_id,))
    return bool(row and row["event_type"] == "Boarded")


def board_student(code: str, bus_id: str, stop: str) -> dict[str, str]:
    student = find_student(code)
    if not student:
        return _result("error", f"No student found for '{code.strip()}'. Check the scanned value.")
    first = student["name"].split()[0]
    if student["bus_id"] != bus_id:  # wrong bus -> flag and notify
        _log(student, "Boarded", bus_id, stop, "Unauthorized bus")
        msg = (f"Warning: unauthorized boarding attempt detected. {student['name']} is not assigned to "
               f"{bus_id} (assigned: {student['bus_id']}).")
        notif.send_notification(student["student_id"], msg, "warning", bus_id)
        notif.notify_admin(msg, "warning", bus_id)
        return _result("error", "🚫 " + msg)
    if is_onboard(student["student_id"]):  # duplicate boarding
        return _result("warning", f"{student['name']} is already onboard - duplicate boarding blocked.")
    _log(student, "Boarded", bus_id, stop, "Verified")
    notif.send_notification(student["student_id"],
                            f"Your child {first} boarded Bus {bus_id} at {db.fmt_time(db.now_str())} (stop: {stop}).",
                            "success", bus_id)
    return _result("success", f"✅ {student['name']} boarded {bus_id} at {stop}. Parent notified (simulated).")


def exit_student(code: str, bus_id: str, stop: str) -> dict[str, str]:
    student = find_student(code)
    if not student:
        return _result("error", f"No student found for '{code.strip()}'. Check the scanned value.")
    first = student["name"].split()[0]
    if student["bus_id"] != bus_id:
        _log(student, "Exited", bus_id, stop, "Unauthorized bus")
        msg = f"Warning: {student['name']} scanned on {bus_id} but is assigned to {student['bus_id']}."
        notif.notify_admin(msg, "warning", bus_id)
        return _result("error", "🚫 " + msg)
    if not is_onboard(student["student_id"]):  # cannot exit without boarding
        return _result("warning", f"{student['name']} is not currently onboard - exit blocked.")
    if stop not in (student["stop_name"], db.SCHOOL_STOP):  # wrong stop
        _log(student, "Exited", bus_id, stop, "Unauthorized stop")
        msg = (f"Warning: {student['name']} tried to exit at {stop}; authorized stop is "
               f"{student['stop_name']} (or {db.SCHOOL_STOP}). Student remains onboard.")
        notif.send_notification(student["student_id"], msg, "warning", bus_id)
        notif.notify_admin(msg, "warning", bus_id)
        return _result("error", "🚫 " + msg)
    _log(student, "Exited", bus_id, stop, "Verified")
    notif.send_notification(student["student_id"], f"Your child {first} exited Bus {bus_id} at {stop}.",
                            "success", bus_id)
    return _result("success", f"✅ {student['name']} exited {bus_id} at {stop}. Parent notified (simulated).")


# ---------------------------------------------------------------- summaries
def currently_onboard(bus_id: Optional[str] = None) -> pd.DataFrame:
    sql = ("SELECT e.student_id, e.student_name, e.bus_id, e.stop_name AS boarded_at_stop, e.event_time "
           "FROM attendance_events e WHERE e.event_type = 'Boarded' AND e.verification_status = 'Verified' "
           f"AND date(e.event_time) = {TODAY} AND e.id = (SELECT MAX(x.id) FROM attendance_events x "
           f"WHERE x.student_id = e.student_id AND x.verification_status = 'Verified' AND date(x.event_time) = {TODAY})")
    params: tuple = ()
    if bus_id:
        sql += " AND e.bus_id = ?"
        params = (bus_id,)
    return db.query_df(sql + " ORDER BY e.event_time", params)


def today_summary(bus_id: Optional[str] = None) -> dict[str, int]:
    """Totals for today: boarded, exited, currently onboard and absent (never boarded)."""
    sql = ("SELECT DISTINCT student_id, event_type FROM attendance_events WHERE verification_status = 'Verified' "
           f"AND date(event_time) = {TODAY}")
    params: tuple = ()
    if bus_id:
        sql += " AND bus_id = ?"
        params = (bus_id,)
    ev = db.query_df(sql, params)
    students = list_students(bus_id)
    boarded = set(ev.loc[ev["event_type"] == "Boarded", "student_id"])
    exited = set(ev.loc[ev["event_type"] == "Exited", "student_id"])
    return {"total": len(students), "boarded": len(boarded), "exited": len(exited),
            "onboard": len(currently_onboard(bus_id)), "absent": len(set(students["student_id"]) - boarded)}


def recent_events(limit: int = 100, student_id: Optional[str] = None) -> pd.DataFrame:
    if student_id:
        return db.query_df("SELECT * FROM attendance_events WHERE student_id = ? ORDER BY id DESC LIMIT ?",
                           (student_id, limit))
    return db.query_df("SELECT * FROM attendance_events ORDER BY id DESC LIMIT ?", (limit,))
