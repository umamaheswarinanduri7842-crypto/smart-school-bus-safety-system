"""AI Smart School Bus Safety System - Streamlit app (educational prototype).

Run with:  streamlit run app.py
All sensor, GPS, notification and AI features are SIMULATED.
"""
from __future__ import annotations

import html
import random
from datetime import date, datetime, timedelta

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from modules import accident_detection as acc
from modules import attendance, camera_ai, reports
from modules import database as db
from modules import gps_tracking as gps
from modules import notifications as notif

FOOTER = "Prototype for educational use. Hardware sensors and real notification services are simulated."
COLORS = {"red": "#d32f2f", "orange": "#f57c00", "green": "#2e7d32", "blue": "#1565c0"}
STATUS_COLOR = {"Active": "red", "New": "red", "Critical": "red", "High": "red", "Unauthorized bus": "red",
                "Unauthorized stop": "red", "Investigating": "orange", "Medium": "orange", "Moderate": "orange",
                "Resolved": "green", "Verified": "green"}
PAGES = ["Dashboard", "Student Attendance", "Live Bus Tracking", "Accident and Emergency Alerts",
         "AI Camera Surveillance", "Parent Portal", "Reports", "System Settings"]

st.set_page_config(page_title="AI Smart School Bus Safety", page_icon="🚌", layout="wide")


# ------------------------------------------------------------------ UI helpers
def badge(text: str, color: str) -> str:
    return (f"<span style='background:{COLORS[color]};color:#fff;padding:2px 10px;border-radius:12px;"
            f"font-size:0.8rem;font-weight:600'>{html.escape(str(text))}</span>")


def status_badge(status: str) -> str:
    return badge(status, STATUS_COLOR.get(status, "blue"))


def banner(text: str, color: str = "red") -> None:
    st.markdown(f"<div style='background:{COLORS[color]};color:#fff;padding:14px 18px;border-radius:8px;"
                f"font-weight:600;margin:6px 0'>{text}</div>", unsafe_allow_html=True)


def header(title: str, description: str, demo: bool = True) -> None:
    st.title(title)
    st.caption(description + ("  ·  🧪 DEMO / SIMULATION data" if demo else ""))


def show_result(result: dict[str, str]) -> None:
    {"success": st.success, "warning": st.warning, "error": st.error}.get(result["level"], st.info)(result["message"])


def bus_ids() -> list[str]:
    return db.query_df("SELECT bus_id FROM buses ORDER BY bus_id")["bus_id"].tolist()


def notification_panel(df: pd.DataFrame, limit: int = 8) -> None:
    if df.empty:
        st.info("No notifications yet.")
        return
    for r in df.head(limit).itertuples():
        color = notif.CATEGORY_COLORS.get(r.category, "blue")
        st.markdown(f"{badge(r.category.title(), color)} &nbsp;{html.escape(r.message)}<br>"
                    f"<small>{r.created_at} · {html.escape(str(r.recipient))} · via {html.escape(str(r.channel))} (simulated)</small>",
                    unsafe_allow_html=True)


def route_map(stops: pd.DataFrame, pos: dict) -> go.Figure:
    """Route + bus on an OpenStreetMap-style Plotly map (works without any API key)."""
    trace = getattr(go, "Scattermap", None) or go.Scattermapbox
    key = "map" if hasattr(go, "Scattermap") else "mapbox"
    fig = go.Figure()
    fig.add_trace(trace(lat=stops["latitude"], lon=stops["longitude"], mode="lines+markers+text",
                        text=stops["stop_name"], textposition="top right", name="Route / stops",
                        marker=dict(size=10, color=COLORS["blue"]), line=dict(width=3, color=COLORS["blue"])))
    fig.add_trace(trace(lat=[pos["latitude"]], lon=[pos["longitude"]], mode="markers", name="Bus",
                        marker=dict(size=18, color=COLORS["red"])))
    fig.update_layout(**{key: dict(style="open-street-map", zoom=12,
                                   center=dict(lat=pos["latitude"], lon=pos["longitude"]))},
                      margin=dict(l=0, r=0, t=0, b=0), height=430, legend=dict(orientation="h"))
    return fig


def safety_notice() -> None:
    st.warning("**Safety & privacy notice** — This is a prototype, not a certified transportation safety system. "
               "GPS, RFID, sensor readings, notifications and AI detections are simulated unless real devices are connected. "
               "Emergency alerts here do **not** contact police, hospitals or emergency services. Facial recognition must not be "
               "enabled without consent and security controls. Production use needs authentication, encryption, access "
               "control, audit logs, secure hosting and legal compliance.")


def alert_banner() -> None:
    """Global red banner shown on every page while an emergency is open."""
    active = acc.list_alerts(status="Active")
    for r in active.itertuples():
        banner(f"🚨 ACTIVE EMERGENCY — {html.escape(r.alert_type)} on {html.escape(r.bus_id)} at {db.fmt_time(r.created_at)}")
    for r in acc.list_accidents(open_only=True).itertuples():
        banner(f"🚨 POSSIBLE ACCIDENT #{r.accident_id} on {html.escape(r.bus_id)} — status {html.escape(r.status)}")


# ------------------------------------------------------------------ pages
def page_dashboard() -> None:
    header("🚌 Dashboard", "Overview of attendance, buses, emergencies and notifications.")
    alert_banner()
    choice = st.selectbox("Bus", ["All buses"] + bus_ids(), key="dash_bus")
    bus = None if choice == "All buses" else choice
    s = attendance.today_summary(bus)
    cols = st.columns(6)
    for col, (label, val) in zip(cols, [("Students", s["total"]), ("Boarded today", s["boarded"]),
                                        ("Onboard now", s["onboard"]), ("Exited today", s["exited"]),
                                        ("Absent today", s["absent"]),
                                        ("Open emergencies", len(acc.list_alerts(status="Active", bus_id=bus))
                                         + len(acc.list_accidents(open_only=True)))]):
        col.metric(label, val)
    left, right = st.columns(2)
    with left:
        st.subheader("Today's attendance")
        fig = px.bar(x=["Onboard", "Exited", "Absent"], y=[s["onboard"], s["exited"], s["absent"]],
                     color=["Onboard", "Exited", "Absent"], labels={"x": "Status", "y": "Students"},
                     color_discrete_map={"Onboard": COLORS["blue"], "Exited": COLORS["green"], "Absent": COLORS["orange"]})
        fig.update_layout(showlegend=False, height=300, margin=dict(t=10))
        st.plotly_chart(fig, key="dash_chart")
        st.subheader("Bus positions (simulated GPS)")
        rows = []
        for b in ([bus] if bus else bus_ids()):
            p = gps.latest_position(b)
            rows.append({"Bus": b, "Route": gps.get_route_name(b), "Stop": p["current_stop"],
                         "Speed (km/h)": p["speed"], "Progress %": round(p["progress"], 1),
                         "Status": "⚠ Off route" if p["off_route"] else "On route"})
        st.dataframe(pd.DataFrame(rows), hide_index=True)
    with right:
        st.subheader("Notification panel")
        notification_panel(notif.get_notifications(limit=10), 8)
    safety_notice()


def student_form(key: str, defaults: dict | None = None, edit: bool = False) -> dict | None:
    d = defaults or {}
    buses = bus_ids()
    stops = db.query_df("SELECT DISTINCT stop_name FROM bus_stops ORDER BY stop_name")["stop_name"].tolist()

    def idx(options: list, value) -> int:
        return options.index(value) if value in options else 0

    with st.form(key):
        c1, c2, c3 = st.columns(3)
        sid = c1.text_input("Student ID", value=d.get("student_id", ""), disabled=edit)
        name = c2.text_input("Student name", value=d.get("name", ""))
        cls = c3.text_input("Class", value=d.get("class_name", ""))
        c4, c5, c6 = st.columns(3)
        parent = c4.text_input("Parent name", value=d.get("parent_name", ""))
        phone = c5.text_input("Parent phone", value=d.get("parent_phone", ""))
        rfid = c6.text_input("RFID / QR value (optional)", value=d.get("rfid_code") or "")
        c7, c8 = st.columns(2)
        bus = c7.selectbox("Assigned bus", buses, index=idx(buses, d.get("bus_id")))
        stop = c8.selectbox("Authorized bus stop", stops, index=idx(stops, d.get("stop_name")))
        submitted = st.form_submit_button("Save changes" if edit else "Add student", type="primary")
    if submitted:
        return {"student_id": d.get("student_id", "") if edit else sid, "name": name, "class_name": cls,
                "parent_name": parent, "parent_phone": phone, "bus_id": bus, "stop_name": stop, "rfid_code": rfid}
    return None


def page_attendance() -> None:
    header("🧒 Student Attendance", "Simulated RFID/NFC/QR scanning, boarding rules and student records.")
    alert_banner()
    tab_scan, tab_onboard, tab_manage, tab_history = st.tabs(["Scan & Board/Exit", "Currently Onboard",
                                                              "Manage Students", "Event History"])
    with tab_scan:
        c1, c2 = st.columns(2)
        bus_id = c1.selectbox("Bus", bus_ids(), key="scan_bus")
        stops = gps.get_route(bus_id)["stop_name"].tolist()
        stop = c2.selectbox("Current bus stop", stops, key=f"scan_stop_{bus_id}")
        code = st.text_input("Simulate scan: RFID / NFC / QR value or Student ID", key="scan_code",
                             placeholder="e.g. RFID-1001 or S001")
        b1, b2, _ = st.columns([1, 1, 3])
        result = None
        if b1.button("Board Student", type="primary"):
            result = attendance.board_student(code, bus_id, stop)
        if b2.button("Exit Student"):
            result = attendance.exit_student(code, bus_id, stop)
        if result:
            show_result(result)
        s = attendance.today_summary(bus_id)
        m = st.columns(4)
        m[0].metric("Boarded today", s["boarded"])
        m[1].metric("Exited today", s["exited"])
        m[2].metric("Onboard now", s["onboard"])
        m[3].metric("Absent today", s["absent"])
        with st.expander("Sample students and codes"):
            st.dataframe(attendance.list_students()[["student_id", "name", "bus_id", "stop_name", "rfid_code"]],
                         hide_index=True)
        st.caption("Rules: one boarding at a time · exit only if onboard · exit allowed at the student's stop or "
                   f"{db.SCHOOL_STOP} · wrong bus/stop attempts are flagged and notified.")
    with tab_onboard:
        onboard = attendance.currently_onboard()
        st.metric("Students onboard (all buses)", len(onboard))
        st.dataframe(onboard, hide_index=True) if not onboard.empty else st.info("No students are onboard right now.")
    with tab_manage:
        action = st.radio("Action", ["Add", "Edit", "Delete"], horizontal=True)
        students = attendance.list_students()
        if action == "Add":
            data = student_form("add_student_form")
            if data:
                show_result(attendance.add_student(data))
        elif students.empty:
            st.info("No students yet.")
        else:
            sid = st.selectbox("Student", students["student_id"], key="manage_sid",
                               format_func=lambda x: f"{x} - {students.set_index('student_id').loc[x, 'name']}")
            if action == "Edit":
                data = student_form(f"edit_form_{sid}", attendance.get_student(sid), edit=True)
                if data:
                    show_result(attendance.update_student(data))
            else:
                confirm = st.checkbox("I understand this permanently deletes the student record", key="del_confirm")
                if st.button("Delete student", disabled=not confirm):
                    st.toast(attendance.delete_student(sid)["message"])
                    st.rerun()
        st.dataframe(attendance.list_students(), hide_index=True)
    with tab_history:
        st.dataframe(attendance.recent_events(200), hide_index=True)


def page_tracking() -> None:
    header("📍 Live Bus Tracking", "Simulated GPS, route progress and stop geofences.")
    alert_banner()
    c1, c2, c3 = st.columns([2, 2, 1])
    bus_id = c1.selectbox("Bus", bus_ids(), key="track_bus")
    deviate = c2.checkbox("Simulate route deviation (demo)", key="deviate")
    c3.write("")
    if c3.button("Refresh GPS", type="primary"):
        try:
            gps.refresh_gps(bus_id, deviate=deviate)
        except Exception as exc:
            st.error(f"GPS refresh failed: {exc}")
    pos = gps.latest_position(bus_id)
    m = st.columns(5)
    m[0].metric("Bus", bus_id)
    m[1].metric("Latitude", f"{pos['latitude']:.5f}")
    m[2].metric("Longitude", f"{pos['longitude']:.5f}")
    m[3].metric("Speed", f"{pos['speed']} km/h")
    m[4].metric("Current stop", pos["current_stop"])
    st.caption(f"Route: {gps.get_route_name(bus_id)} · last update {pos['logged_at']}")
    st.progress(min(1.0, pos["progress"] / 100), text=f"Route progress: {pos['progress']:.0f}%")
    if pos["off_route"]:
        st.error("⚠️ WARNING: bus is outside its assigned route corridor (geofence breach).")
    else:
        st.success("Bus is on its assigned route.")
    stops = gps.get_route(bus_id)
    tab_map, tab_route, tab_log = st.tabs(["Map", "Route & stops", "GPS log"])
    with tab_map:
        st.plotly_chart(route_map(stops, pos), key="track_map")
        st.caption("Map tiles need an internet connection; coordinates are also shown above and in the tables.")
    with tab_route:
        points = gps.stop_progress_points(stops.to_dict("records"))
        stops = stops.assign(reaches_at_percent=points,
                             status=["✅ Passed" if pos["progress"] >= p else "⏳ Upcoming" for p in points])
        st.dataframe(stops, hide_index=True)
    with tab_log:
        st.dataframe(gps.recent_logs(bus_id), hide_index=True)


def _sensor_defaults() -> None:
    for k, v in dict(ax=0.2, ay=0.1, az=9.8, gx=1.0, gy=0.5, gz=0.3, speed=35.0, lat=34.06, lon=-118.26,
                     ts=db.now_str()).items():
        st.session_state.setdefault(k, v)


def _load_normal() -> None:
    st.session_state.update(ax=round(random.uniform(-1.5, 1.5), 2), ay=round(random.uniform(-1.5, 1.5), 2),
                            az=round(random.uniform(9.2, 10.4), 2), gx=round(random.uniform(-10, 10), 1),
                            gy=round(random.uniform(-10, 10), 1), gz=round(random.uniform(-10, 10), 1),
                            speed=round(random.uniform(20, 45), 1), ts=db.now_str())


def _load_crash() -> None:
    st.session_state.update(ax=round(random.uniform(28, 45), 2), ay=round(random.uniform(-20, 20), 2),
                            az=round(random.uniform(5, 15), 2), gx=round(random.uniform(150, 350), 1),
                            gy=round(random.uniform(-200, 200), 1), gz=round(random.uniform(-100, 100), 1),
                            speed=round(random.uniform(0, 8), 1), ts=db.now_str())


def _use_gps() -> None:
    pos = gps.latest_position(st.session_state["acc_bus"])
    st.session_state.update(lat=round(pos["latitude"], 6), lon=round(pos["longitude"], 6), speed=pos["speed"])


def _accident_tab() -> None:
    _sensor_defaults()
    st.info("🧪 DEMO: sensor values are typed in or randomly generated - no real accelerometer/gyroscope is connected.")
    bus_id = st.selectbox("Bus", bus_ids(), key="acc_bus")
    a_thr, g_thr = acc.get_thresholds()
    st.caption(f"Current thresholds: acceleration {a_thr} m/s², gyroscope {g_thr} °/s (change in System Settings).")
    b1, b2, b3, _ = st.columns([1, 1, 1, 2])
    b1.button("Load normal driving values", on_click=_load_normal)
    b2.button("Load crash-like values", on_click=_load_crash)
    b3.button("Use current GPS position", on_click=_use_gps)
    c = st.columns(3)
    c[0].number_input("Acceleration X (m/s²)", key="ax", step=0.5)
    c[1].number_input("Acceleration Y (m/s²)", key="ay", step=0.5)
    c[2].number_input("Acceleration Z (m/s²)", key="az", step=0.5)
    g = st.columns(3)
    g[0].number_input("Gyroscope X (°/s)", key="gx", step=5.0)
    g[1].number_input("Gyroscope Y (°/s)", key="gy", step=5.0)
    g[2].number_input("Gyroscope Z (°/s)", key="gz", step=5.0)
    o = st.columns(4)
    o[0].number_input("Vehicle speed (km/h)", key="speed", min_value=0.0, step=1.0)
    o[1].number_input("Bus latitude", key="lat", format="%.6f", step=0.0001)
    o[2].number_input("Bus longitude", key="lon", format="%.6f", step=0.0001)
    o[3].text_input("Sensor timestamp", key="ts")
    if st.button("Generate Sensor Reading", type="primary"):
        ss = st.session_state
        reading = {"ax": ss.ax, "ay": ss.ay, "az": ss.az, "gx": ss.gx, "gy": ss.gy, "gz": ss.gz, "speed": ss.speed,
                   "latitude": ss.lat, "longitude": ss.lon, "timestamp": ss.ts or db.now_str()}
        res = acc.process_reading(bus_id, reading)
        m = st.columns(3)
        m[0].metric("Acceleration magnitude", res["accel_mag"], f"threshold {res['accel_threshold']}", delta_color="off")
        m[1].metric("Gyroscope magnitude", res["gyro_mag"], f"threshold {res['gyro_threshold']}", delta_color="off")
        m[2].metric("Result", "ACCIDENT" if res["detected"] else "Normal")
        if res["detected"]:
            banner(f"🚨 POSSIBLE ACCIDENT DETECTED — severity {res['severity']} (accident #{res['accident_id']})")
            st.write(f"**Live location:** {reading['latitude']:.5f}, {reading['longitude']:.5f}")
            st.plotly_chart(route_map(gps.get_route(bus_id), {"latitude": reading["latitude"],
                                                              "longitude": reading["longitude"]}), key="acc_map")
        else:
            st.success("Reading is within normal limits. No accident detected.")
    open_acc = acc.list_accidents(open_only=True)
    if not open_acc.empty:
        st.subheader("Open accidents")
        st.write("**Emergency contacts (simulated - nobody is called automatically):**")
        for line in acc.get_emergency_contacts():
            st.write(f"- {line}")
        for r in open_acc.itertuples():
            cols = st.columns([4, 1, 1])
            cols[0].markdown(f"{status_badge(r.status)} {status_badge(r.severity)} &nbsp; **#{r.accident_id}** · {r.bus_id} · "
                             f"{r.event_time} · {r.latitude:.5f}, {r.longitude:.5f}", unsafe_allow_html=True)
            if cols[1].button("Investigating", key=f"inv_{r.accident_id}", disabled=r.status == "Investigating"):
                acc.update_accident_status(r.accident_id, "Investigating")
                st.rerun()
            if cols[2].button("Mark Resolved", key=f"res_{r.accident_id}"):
                acc.update_accident_status(r.accident_id, "Resolved")
                st.rerun()
    with st.expander("Accident history"):
        st.dataframe(acc.list_accidents(), hide_index=True)


def _manual_tab() -> None:
    bus_id = st.selectbox("Bus", bus_ids(), key="em_bus")
    st.markdown(" ".join([badge("Active emergency", "red"), badge("Warning", "orange"), badge("Resolved", "green"),
                          badge("Information", "blue")]), unsafe_allow_html=True)
    cols = st.columns(len(acc.ALERT_TYPES))
    for col, alert_type in zip(cols, acc.ALERT_TYPES):
        if col.button(alert_type, key=f"btn_{alert_type}", type="primary"):
            a = acc.create_emergency_alert(bus_id, alert_type)
            banner(f"🚨 {html.escape(a['alert_type'])} — {html.escape(a['bus_id'])} — {a['time']} — "
                   f"GPS {a['latitude']:.5f}, {a['longitude']:.5f}")
            st.info("Simulated notifications were sent to the school administrator and parents. "
                    "No real emergency service was contacted.")
    if acc.siren_active():
        st.error("🔊 Buzzer / siren: ON (simulated)")
    else:
        st.success("🔇 Buzzer / siren: OFF (simulated)")
    st.subheader("Active alerts")
    active = acc.list_alerts(status="Active")
    if active.empty:
        st.info("No active alerts.")
    for r in active.itertuples():
        cols = st.columns([5, 1])
        cols[0].markdown(f"{status_badge('Active')} **{r.alert_type}** · {r.bus_id} · {r.created_at} · "
                         f"{r.latitude:.5f}, {r.longitude:.5f}", unsafe_allow_html=True)
        if cols[1].button("Resolve Alert", key=f"resolve_{r.id}"):
            acc.resolve_alert(r.id)
            st.rerun()
    with st.expander("Alert history"):
        st.dataframe(acc.list_alerts(), hide_index=True)


def page_emergency() -> None:
    header("🚨 Accident and Emergency Alerts", "Rule-based accident detection and manual SOS alerts.")
    alert_banner()
    tab_acc, tab_manual = st.tabs(["Accident detection", "Manual emergency alerts"])
    with tab_acc:
        _accident_tab()
    with tab_manual:
        _manual_tab()
    st.caption("Emergency alerts in this prototype do not automatically contact police, hospitals or emergency services.")


def page_camera() -> None:
    header("📷 AI Camera Surveillance", "Upload an image or short video and run a simulated safety scan.")
    alert_banner()
    st.info("🔒 Privacy: facial recognition is NOT used. Real facial recognition requires consent, secure storage "
            "and compliance with privacy laws.")
    c1, c2, c3 = st.columns(3)
    bus_id = c1.selectbox("Bus", bus_ids(), key="cam_bus")
    location = c2.selectbox("Camera location", camera_ai.CAMERA_LOCATIONS, key="cam_loc")
    modes = [camera_ai.MODE_MOCK] + ([camera_ai.MODE_CV] if camera_ai.opencv_available() else []) \
        + ([camera_ai.MODE_YOLO] if camera_ai.yolo_available() else [])
    mode = c3.selectbox("Detection mode", modes, key="cam_mode")
    file = st.file_uploader("Upload an image or short video", type=["jpg", "jpeg", "png", "mp4", "avi", "mov"])
    is_video = bool(file and file.name.lower().endswith((".mp4", ".avi", ".mov")))
    if file:
        if is_video:
            st.video(file.getvalue())
        else:
            st.image(file.getvalue(), caption=file.name)
    if st.button("Run AI Safety Scan", type="primary"):
        try:
            with st.spinner("Scanning..."):
                res = camera_ai.run_scan(mode, file.getvalue() if file else None, file.name if file else "",
                                         is_video, location, bus_id)
            color = {"High": "red", "Medium": "orange", "Low": "blue", "Info": "green"}[res["severity"]]
            banner(f"{html.escape(res['detection'])} — confidence {res['confidence']:.0%} — severity {res['severity']}", color)
            st.write(f"**Time:** {res['time']}  ·  **Camera:** {location}  ·  **Bus:** {bus_id}  ·  **Mode:** {mode}")
            st.caption(res["details"] + " (DEMO result - not a real safety determination)")
        except Exception as exc:
            st.error(f"Scan failed: {exc}")
    if not file:
        st.caption("No media uploaded: the mock detector will still produce a random demo result.")
    st.subheader("Detection history")
    st.dataframe(camera_ai.list_camera_events(), hide_index=True)


def page_parent() -> None:
    header("👪 Parent Portal", "Check your child's bus status.")
    st.warning("Prototype access: enter a Student ID (e.g. S001). There is no real login - production use requires "
               "proper authentication so parents only see their own child.")
    sid = st.text_input("Student ID", key="parent_sid")
    if not sid.strip():
        return
    student = attendance.get_student(sid)
    if not student:
        st.error("Student ID not found.")
        return
    sid, bus_id = student["student_id"], student["bus_id"]  # only this student's data is queried below
    pos = gps.latest_position(bus_id)
    st.subheader(student["name"])
    m = st.columns(4)
    m[0].metric("Assigned bus", bus_id)
    m[1].metric("Route", gps.get_route_name(bus_id))
    m[2].metric("Bus location", f"{pos['latitude']:.4f}, {pos['longitude']:.4f}")
    m[3].metric("Bus at", pos["current_stop"])
    events = attendance.recent_events(200, sid)
    verified = events[events["verification_status"] == "Verified"]
    last_board = verified[verified["event_type"] == "Boarded"].head(1)
    last_exit = verified[verified["event_type"] == "Exited"].head(1)
    c1, c2 = st.columns(2)
    c1.info("Latest boarding: " + (f"{last_board.iloc[0]['event_time']} at {last_board.iloc[0]['stop_name']}"
                                   if not last_board.empty else "none recorded"))
    c2.info("Latest exit: " + (f"{last_exit.iloc[0]['event_time']} at {last_exit.iloc[0]['stop_name']}"
                               if not last_exit.empty else "none recorded"))
    alerts = acc.list_alerts(status="Active", bus_id=bus_id)
    open_acc = acc.list_accidents(open_only=True)
    open_acc = open_acc[open_acc["bus_id"] == bus_id]
    if alerts.empty and open_acc.empty:
        st.success("No active emergency alerts for your child's bus.")
    for r in alerts.itertuples():
        banner(f"🚨 {html.escape(r.alert_type)} reported on {html.escape(r.bus_id)} at {db.fmt_time(r.created_at)}")
    for r in open_acc.itertuples():
        banner(f"🚨 Possible incident on {html.escape(r.bus_id)} at {db.fmt_time(r.event_time)} (status {html.escape(r.status)})")
    tab_hist, tab_notif, tab_trip = st.tabs(["Attendance history", "Notifications", "Recent trip"])
    with tab_hist:
        st.dataframe(events, hide_index=True)
    with tab_notif:
        notification_panel(notif.get_notifications(sid, 30), 30)
    with tab_trip:
        today = events[events["event_time"].str.startswith(date.today().isoformat())]
        recent = today if not today.empty else events.head(6)
        st.caption("Today's trip events" if not today.empty else "No events today - showing most recent events")
        st.dataframe(recent[["event_time", "event_type", "bus_id", "stop_name", "verification_status"]], hide_index=True)
        st.write(f"Bus progress on {gps.get_route_name(bus_id)}: {pos['progress']:.0f}%")


def _bar(df: pd.DataFrame, col: str, key: str, title: str) -> None:
    counts = df[col].value_counts().reset_index()
    counts.columns = [col, "count"]
    fig = px.bar(counts, x=col, y="count", title=title)
    fig.update_layout(height=300)
    st.plotly_chart(fig, key=f"chart_{key}")


def _report(df: pd.DataFrame, key: str, filename: str, chart_col: str | None, title: str) -> None:
    st.metric("Records", len(df))
    if df.empty:
        st.info("No records match the filters.")
    else:
        if chart_col:
            _bar(df, chart_col, key, title)
        st.dataframe(df, hide_index=True)
    st.download_button("Download CSV", reports.to_csv_bytes(df), file_name=filename, mime="text/csv", key=f"dl_{key}")


def page_reports() -> None:
    header("📊 Reports", "Filter, chart and export school bus safety records.", demo=False)
    students = attendance.list_students().set_index("student_id")["name"].to_dict()
    c1, c2, c3 = st.columns(3)
    today = date.today()
    rng = c1.date_input("Date range", value=(today - timedelta(days=7), today), key="rep_range")
    bus = c2.selectbox("Bus", ["All"] + bus_ids(), key="rep_bus")
    stu = c3.selectbox("Student", [""] + list(students), key="rep_student",
                       format_func=lambda x: "All" if not x else f"{x} - {students[x]}")
    if not (isinstance(rng, (tuple, list)) and len(rng) == 2):
        st.info("Pick both a start and an end date.")
        return
    start, end = rng[0].isoformat(), rng[1].isoformat()
    bus_f, stu_f = (None if bus == "All" else bus), (stu or None)
    tabs = st.tabs(["Daily attendance", "Onboard now", "Unauthorized attempts", "Accidents", "Emergency alerts",
                    "Camera detections", "Bus activity"])
    with tabs[0]:
        df = reports.daily_attendance(start, end, bus_f, stu_f)
        if not df.empty:
            df = df.assign(date=df["event_time"].str[:10])
            per_day = df.groupby(["date", "event_type"]).size().reset_index(name="count")
            st.plotly_chart(px.bar(per_day, x="date", y="count", color="event_type", barmode="group",
                                   title="Verified boardings and exits per day"), key="chart_daily")
            df = df.drop(columns="date")
        _report(df, "daily", "daily_attendance.csv", None, "")
    with tabs[1]:
        _report(reports.onboard_now(bus_f, stu_f), "onboard", "students_onboard.csv", "bus_id", "Students onboard by bus")
    with tabs[2]:
        _report(reports.unauthorized_attempts(start, end, bus_f, stu_f), "unauth", "unauthorized_attempts.csv",
                "verification_status", "Unauthorized attempts by type")
    with tabs[3]:
        _report(reports.accident_history(start, end, bus_f), "acc", "accidents.csv", "severity", "Accidents by severity")
    with tabs[4]:
        _report(reports.emergency_history(start, end, bus_f), "alerts", "emergency_alerts.csv", "alert_type",
                "Alerts by type")
    with tabs[5]:
        _report(reports.camera_history(start, end, bus_f), "cam", "camera_events.csv", "detection", "Detections by type")
    with tabs[6]:
        df = reports.bus_activity(start, end, bus_f)
        if not df.empty:
            st.plotly_chart(px.bar(df.melt(id_vars="bus_id", var_name="metric", value_name="count"), x="bus_id",
                                   y="count", color="metric", barmode="group", title="Activity by bus"), key="chart_bus")
        _report(df, "bus", "bus_activity.csv", None, "")


def page_settings() -> None:
    header("⚙️ System Settings", "Administrator settings (no login in this prototype).", demo=False)
    with st.form("settings_form"):
        channel = st.radio("Simulated notification channel", notif.CHANNELS, horizontal=True,
                           index=notif.CHANNELS.index(db.get_setting("notification_channel", "Mobile App")))
        a_thr, g_thr = acc.get_thresholds()
        c1, c2, c3 = st.columns(3)
        new_a = c1.number_input("Acceleration threshold (m/s²)", min_value=1.0, value=a_thr, step=1.0)
        new_g = c2.number_input("Gyroscope threshold (°/s)", min_value=1.0, value=g_thr, step=10.0)
        new_tol = c3.number_input("Route tolerance (metres)", min_value=10, value=int(float(db.get_setting("route_tolerance_m", "150"))), step=10)
        contacts = st.text_area("Emergency contacts (one per line, informational only)", value=db.get_setting("emergency_contacts"))
        if st.form_submit_button("Save settings", type="primary"):
            db.set_setting("notification_channel", channel)
            db.set_setting("accel_threshold", new_a)
            db.set_setting("gyro_threshold", new_g)
            db.set_setting("route_tolerance_m", new_tol)
            db.set_setting("emergency_contacts", contacts)
            st.success("Settings saved.")
    st.subheader("Reset demo data")
    st.write("Deletes ALL records and restores the sample students, buses and history.")
    confirm = st.checkbox("Yes, reset everything", key="reset_confirm")
    if st.button("Reset demo data", disabled=not confirm):
        db.reset_demo_data()
        st.success("Demo data restored.")
    safety_notice()


# ------------------------------------------------------------------ main
def main() -> None:
    if "db_ready" not in st.session_state:
        try:
            db.init_db()
            st.session_state["db_ready"] = True
        except Exception as exc:
            st.error(f"Database initialisation failed: {exc}")
            st.stop()
    st.sidebar.title("🚌 Smart Bus Safety")
    st.sidebar.caption("PROTOTYPE · DEMO / SIMULATION")
    page = st.sidebar.radio("Navigation", PAGES, key="nav")
    st.sidebar.info(f"Time: {datetime.now():%Y-%m-%d %H:%M}")
    {"Dashboard": page_dashboard, "Student Attendance": page_attendance, "Live Bus Tracking": page_tracking,
     "Accident and Emergency Alerts": page_emergency, "AI Camera Surveillance": page_camera,
     "Parent Portal": page_parent, "Reports": page_reports, "System Settings": page_settings}[page]()
    st.divider()
    st.caption(FOOTER)


main()
