Assets folder
=============
Place optional static files here (logos, sample images or short sample videos for the
AI Camera Surveillance page). The app does not require any files in this folder.
Do not store real student photos or other personal data here in a demo project.
